from distutils.core import setup

setup(name="Producs Manager",
      version="0.1",
      description="Venta de articulos",
      author="Daniel Souto",
      author_email="dsoutofernandez @danielcastelao.org",
      url="http://google.es",
      license="GPL",
      scripts=["Productos.py"],


      )