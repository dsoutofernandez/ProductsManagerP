import sqlite3 as produtos
from gi.repository import Gtk

settings = Gtk.Settings.get_default()
settings.props.gtk_button_images = True
class Products:
    #Creamos acceso a las ventanas de glade
    archivoVentanaPrincipal = "VentanaPrincipal.glade"
    archivoVentanaConsulta = "VentanaConsulta.glade"
    archivoVentanaIntroducir = "VentanaIntroducir.glade"
    archivoVentanaEliminar = "VentanaEliminar.glade"
    archivoVentanaAlerta = "Alertacodigo.glade"
    archivoVentanaArticuloEliminado = "VentanaArticuloEliminado.glade"
    #Creamos constructores de GTK para las interfaces
    builderVentanaAlerta = Gtk.Builder()
    builderVentanaPrincipal = Gtk.Builder()
    builderVentanaConsulta = Gtk.Builder()
    builderVentanaIntroducir = Gtk.Builder()
    builderVentanaEliminar = Gtk.Builder()
    builderVentanaArticuloEliminado = Gtk.Builder()
    #Añadimos los archivos a los constructores de la interface
    builderVentanaPrincipal.add_from_file(archivoVentanaPrincipal)
    builderVentanaConsulta.add_from_file(archivoVentanaConsulta)
    builderVentanaIntroducir.add_from_file(archivoVentanaIntroducir)
    builderVentanaEliminar.add_from_file(archivoVentanaEliminar)
    builderVentanaAlerta.add_from_file(archivoVentanaAlerta)
    builderVentanaArticuloEliminado.add_from_file(archivoVentanaArticuloEliminado)
    #Recogemos las ventanas contenedoras
    ventanaEntrada = builderVentanaPrincipal.get_object("VentanaPrincipal")
    ventanaConsultas = builderVentanaConsulta.get_object("VentanaConsulta")
    ventanaIntroducir = builderVentanaIntroducir.get_object("VentanaIntroducir")
    ventanaEliminar = builderVentanaEliminar.get_object("VentanaEliminar")
    ventanaAlertaCodigo = builderVentanaAlerta.get_object("AlertaCodigo")
    ventanaAlertaArchivoEliminado = builderVentanaArticuloEliminado.get_object("VentanaArticuloEliminado")
    ventanaEntrada.show_all()
    #Conectamenos a la base de datos y creamos un cursor para recorrerla
    bd = produtos.connect("productos.dat")
    print(bd)
    cursor = bd.cursor()



#Funciones de búsqueda y modificación:
    def al_buscar(self, busqueda):
        #Recogemos el codigo de la caja de texto
        codigo = self.cajaIdConsulta.get_text()
        #Buscamos el codigo recogido en la base de datos
        self.cursor.execute("Select * from productos where Codigo='"+codigo+"'")
        #Recorremos el cursor y mostraremos por pantalla si existe
        for producto in self.cursor:
            self.cajaNombreConsultada.set_text(str(producto[1]))
            self.cajaPrecioConsultada.set_text(str(producto[2]))
            self.cajaCantidadConsultada.set_text(str(producto[3]))


    def introducirStock(self, introducir):
        id = self.cajaIntroducirCodId.get_text()
        nombre = self.cajaIntroducirNombre.get_text()
        precio = self.cajaIntroducirPrecio.get_text()
        cantidad = self.cajaIntroducirCantidad.get_text()
        self.limpiarIntroducir(self)
        print("inserte")
        self.cursor.execute("select codigo from productos")
        #Recogemos los codigos de los productos para despues descartar si esta o no en la base
        codigos = self.cursor.fetchall()
        existe=False
        for producto in codigos:

            idCompare = str(producto)
            #Si esta en la base; existe pasa a True y no se añadirá a la base
            if idCompare[2:4]==id:
                print("Ya existe ese codigo!!")
                self.ventanaAlertaCodigo.show_all()
                existe=True

        if existe==False:
            #Introducimos valores en la tabla
            self.cursor.execute("insert into productos values('" + id + "','" + nombre + "','" + precio + "','" + cantidad + "')")
            print("Insertado")
            #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
            self.bd.commit()

        existe=False


    def al_modificar(self, modificacion):
        #Definimos variables de texto que recogeran el texto que hay en las cajas
        nombre = self.cajaNombreConsultada.get_text()
        precio = self.cajaPrecioConsultada.get_text()
        cantidad = self.cajaCantidadConsultada.get_text()
        id = self.cajaIdConsulta.get_text()
        #Actualizamos los datos de la tabla en esa posicion mediante un Update
        self.cursor.execute(
            "update productos set Nombre ='" + nombre + "',Precio='" + precio + "',Cantidad='" + cantidad + "'" + " where Codigo='" + id + "'")
        print("Modificado")
        #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
        self.bd.commit()
        #Borramos las cajas usadas ya actualizadas
        self.cajaNombreConsultada.set_text("")
        self.cajaPrecioConsultada.set_text("")
        self.cajaCantidadConsultada.set_text("")


    def Eliminar(self, eliminado):
        #Recoje el codigo al igual que la función buscar; la diferencia es que esta ejecute un delete pasando como parámetro el código
        cajaEliminar = self.cajaEliminar.get_text()
        self.cursor.execute("delete from productos where Codigo ='" + cajaEliminar + "'")
        print("Borrado")
        self.ventanaAlertaArchivoEliminado.show_all()
        #Importante efectuar commits en cada modificacion para asegurarnos la integridad de los datos en la misma
        self.bd.commit()
        #Borramos la caja de Eliminar ya usada
        self.cajaEliminar.set_text("")



#Funciones de limpieza de cajas de texto según Ventana
    def click_limpiarConsulta(self,limpieza):
        self.cajaIdConsulta.set_text("")
        self.cajaNombreConsultada.set_text("")
        self.cajaPrecioConsultada.set_text("")
        self.cajaCantidadConsultada.set_text("")


    def limpiarIntroducir(self, introduccion):
        self.cajaIntroducirCodId.set_text("")
        self.cajaIntroducirNombre.set_text("")
        self.cajaIntroducirPrecio.set_text("")
        self.cajaIntroducirCantidad.set_text("")



#Funciones de muestra y ocultacion de ventanas según clicks:
    def click_introducir(self, entrada):
        self.ventanaEntrada.hide()
        self.ventanaIntroducir.show_all()


    def click_consultar(self, consulta):
        self.ventanaEntrada.hide()
        self.ventanaConsultas.show_all()


    def Eliminar_articulo(self,eliminado):
        self.ventanaEntrada.hide()
        self.ventanaEliminar.show_all()



#Funciones de vuelta a la ventana principal
    def click_volverConsulta(self, vuelta):
        self.click_limpiarConsulta(self)
        self.ventanaConsultas.hide()
        self.ventanaEntrada.show_all()


    def volverIntroducir(self, vuelta):
        self.limpiarIntroducir(self)
        self.ventanaIntroducir.hide()
        self.ventanaEntrada.show_all()


    def volverEliminar(self, vuelta):
        self.cajaEliminar.set_text("")
        self.ventanaEliminar.hide()
        self.ventanaEntrada.show_all()



#Declaración Inicial de handlers(manejadores, señales) y entrada de ventana Principal al iniciar la aplicación
    def __init__(self):
        #Mostramos la ventana principal
        self.ventanaEntrada.show_all();
        #Manejadores; funciones definidas en Glade con su equivalencia en Python
        manejadores = {
                  "click_limpiarConsulta":self.click_limpiarConsulta,
                  "click_volverConsulta":self.click_volverConsulta,
                  "limpiarCamposIntroducir":self.limpiarIntroducir,
                  "click_introducirStock":self.introducirStock,
                  "Eliminar_articulo":self.Eliminar_articulo,
                  "click_introducir": self.click_introducir,
                  "volverIntroducir":self.volverIntroducir,
                  "click_consultar": self.click_consultar,
                  "volverEliminar":self.volverEliminar,
                  "click_modificar":self.al_modificar,
                  "cerrarAlertaCodigo":self.alerta,
                  "al_buscar":self.al_buscar,
                  "Terminar1":self.Terminar,
                  "Terminar2":self.Terminar,
                  "Terminar3":self.Terminar,
                  "Terminar":self.Terminar,
                  "Eliminar":self.Eliminar,
                  "botonOk":self.BotonOk
        }
        #Conectamos los constructores con los manejadores
        self.builderVentanaPrincipal.connect_signals(manejadores)
        self.builderVentanaConsulta.connect_signals(manejadores)
        self.builderVentanaIntroducir.connect_signals(manejadores)
        self.builderVentanaEliminar.connect_signals(manejadores)
        self.builderVentanaAlerta.connect_signals(manejadores)
        self.builderVentanaArticuloEliminado.connect_signals(manejadores)

        #Recojemos las cajas de las ventanas
        self.cajaIdConsulta = self.builderVentanaConsulta.get_object("cajaIdConsulta")
        self.cajaNombreConsultada = self.builderVentanaConsulta.get_object("cajaNombreConsultada")
        self.cajaPrecioConsultada = self.builderVentanaConsulta.get_object("cajaPrecioConsultada")
        self.cajaCantidadConsultada = self.builderVentanaConsulta.get_object("cajaCantidadConsultada")
        self.cajaIntroducirCodId = self.builderVentanaIntroducir.get_object("cajaIntroducirCodId")
        self.cajaIntroducirNombre = self.builderVentanaIntroducir.get_object("cajaIntroducirNombre")
        self.cajaIntroducirPrecio = self.builderVentanaIntroducir.get_object("cajaIntroducirPrecio")
        self.cajaIntroducirCantidad = self.builderVentanaIntroducir.get_object("cajaIntroducirCantidad")
        self.cajaEliminar = self.builderVentanaEliminar.get_object("cajaEliminar")



    def alerta(self, alerta):
        self.ventanaAlertaCodigo.hide()



    def BotonOk(self,ok):
        self.ventanaAlertaArchivoEliminado.hide()



#Función de cierre del programa
    def Terminar(self, dos, tres):
        #Cerramos todas las ventanas y el main
        self.ventanaEntrada.connect("delete-event", Gtk.main_quit)
        self.ventanaIntroducir.connect("delete-event", Gtk.main_quit)
        self.ventanaEliminar.connect("delete-event", Gtk.main_quit)
        self.ventanaConsultas.connect("delete-event", Gtk.main_quit)
        Gtk.main_quit()


Products()
Gtk.main()
#Queda pendiente la inclusión de pequeñas consolas  que avisen del resultado de los eventos
#(si se ha actualizado,borrado,... con exito o no) y la discriminacion de datos
#segun sean caracteres o números